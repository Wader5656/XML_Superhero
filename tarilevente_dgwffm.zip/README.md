Tari Levente Fejlett XML Technológiák beadandó feladat

Az összes kimenet a docs mappába van elhelyezve.

Superhero-api

1. JSON: A teljes json kiíratása az apiról.
2. JSON: Minden szuperhős nevének és rasszának kiíratása, akinek nincs megadva a neme.
3. JSON: Azon hősök nevének és erejének kiíratása, akiknek a "durability" értékük 100 és a "strenght" nagyobb, mint 80 "intelligence" szerint rendezve.
4. JSON(érték) Hány darab hősnek volt az első szereplése valamelyik avangers filmben.
5. JSON: A legmagasabb és legnehezebb hős(ök) nevének, magasságának és súlyának kiírása.
6. XML: Melyik kiadó(k) adta/adták ki a legtöbb/legkevesebb szuperhőst.
7. XML: Fajonként a leghosszabb nevű  személy kiíratása Fullname alapján.(legtöbb darabból rakódik össze) Ha több is van, akkor a legelső megtalált nevet írja ki. 
8. XML: Női, illetve férfi szuperhősök átlag magassága illetve testsúlya.
9. XML: Az összes olyan hős statisztikáinak kiírtatása akik valahogy kötődnek zöldlámpáshoz, harc érték alapján csökkenően rendezve.
10. HTML: Egy html kimeneten a férfiak és nők száma szemszínenként, hozzáadott arány oszloppal, hogy a szuperhősök hány %-a rendelkezik azzal a szemszínnel.
